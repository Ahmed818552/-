
import 'package:flutter/material.dart';

void main() {
  runApp(WordOfTheDayApp());
}

class WordOfTheDayApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: WordScreen(),
    );
  }
}

class WordScreen extends StatelessWidget {
  final String word = "Serendipity";
  final String meaning = "The occurrence of happy or beneficial events by chance.";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Word of the Day")),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(word, style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
              SizedBox(height: 20),
              Text(meaning, style: TextStyle(fontSize: 18)),
            ],
          ),
        ),
      ),
    );
  }
}
